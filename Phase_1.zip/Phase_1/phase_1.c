//Copyright (c) 2022 Soteris Kettenis (sotiris056), Lucas Berenguier (Berenguier), Ludovic Loubeau (LoubeauL), Camile Bertramond (CamilleBtd), Oceanne Ravier (OceanneRvr)

#include <stdio.h>
#include <elf.h>
#include <stdlib.h>
#include <string.h>
#include "phase_1.h"
#include "util.h"
#include <sys/types.h> 
#include <sys/stat.h>
#include <unistd.h>
#include "arithmetic_functions.h"


void get_header(FILE * in, char * tab, int len) // tab en char unint32_t version =reverse() *(unint32_t *) &tab[8]) + renverser octet 
                                        // m2 mieux struct p18 doc + fread avec addresse header size of 
{
    int i = 0;
    char c=fgetc(in);
    while (i<len)
    {   
        tab[i] = c;
        //printf("tab[i] = %02X\n", tab[i]);
        i++;
        c=fgetc(in);
    }
    //printf(" c fin = %02X\n", c);
    //tab[i] = '\0';
    tab[len] = '\0';
    //printf("%ld strlen\n", strlen(tab));

}

//Magic Number
char * get_magic_number(char tab[65])
{
    char * res = (char *) malloc (17 * sizeof(char));
    printf(" Magic:    ");
    for (int i = 0; i < 16; i++)
    {
        res[i] = tab[i];
        printf("%02X ", tab[i]);
    }
    res[16] = '\0';
    printf("\n");
    return res;
}

//Class
char get_class(char tab[65])
{
    printf(" Class:                              ");
    switch(tab[4])
    {
        case 0:
            printf("Invalid\n");
            return '0';
        case 1:
            printf("ELF32\n");
            return '1';
        case 2:
            printf("ELF64\n");
            return '2';
    }
    return '0';
}

//Data
char get_data(char tab[65])
{
    printf(" Data:                               ");
    switch (tab[5])
    {
        case 1 :
            printf("2's complement, little endian\n");
            return '1';
        case 2 :
            printf("2's complement, big endian\n");
            return '2';
        default :
            printf("Invalid data encoding\n");
            return '0';
    }
}

//Version
char get_version(char tab[65])
{
    printf(" Version:                            ");
    if (tab[6] == 1)
    {
        printf("%X (current)\n", tab[6]);
        return '1';
    }
    else
    {
        printf("Invalid version\n");
        return '0';
    }
}

//OS/ABI
int get_os_abi(char tab[65])
{
    printf(" OS/ABI:                             ");
    switch (tab[7]){
        case 0 :
            printf("UNIX - System V\n");
            return 0;
        case 1 :
            printf("HP-UX\n");
            return 1;
        case 2 :
            printf("NetBSD\n");
            return 2;
        case 3 :
            printf("Linux\n");  
            return 3;
        case 4:
            printf("GNU Hurd\n");
            return 4;
        case 6 :
            printf("Sun Solaris\n");
            return 6;
        case 7 :
            printf("IBM AIX\n");
            return 7;
        case 8 :
            printf("SGI Irix\n");
            return 8;
        case 9 :
            printf("FreeBSD\n");
            return 9;
        case 10 :
            printf("Compaq TRU64\n");
            return 10;
        case 11 :
            printf("Novell Modesto\n");
            return 11;
        case 12 :
            printf("OpenBSD\n");
            return 12;
        case 13:
            printf("OpenVMS\n");
            return 13;
        case 14:
            printf("NonStop Kernel\n");
            return 14;
        case 15:
            printf("AROS\n");
            return 15;
        case 16:
            printf("Fenix OS\n");
            return 16;
        case 17:
            printf("CloudABI\n");
            return 17;
        case 18:
            printf("Stratus Technologies OpenVOS");
            return 18;
        case 64 :
            printf("ARM EABI\n");
            return 64;
        case 97 :
            printf("ARM\n");
            return 97;
        default:
            return -1;
    }
}

//Version ABI
char get_abi_version(char  tab[65])
{
    printf(" ABI Version :                       %X\n",tab[8]);
    return tab[8];
}

//Type (tab[16] + tab[17])
char get_type(char tab[65])
{
    printf(" Type :                              ");
    
    //char str[17] = {'\0'};
    //int elf_type;
    uint16_t * type = (uint16_t *) &tab[16];
    *type = reverse_2(* type);
    switch (*type){
        case 1 :
            printf("REL (Relocatable file)\n");
            return(*type);
        case 2 :
            printf("Executable\n");
            return(*type);
        case 3 :
            printf("shared object\n");  
            return(*type);
        case 4 :
            printf("Core file\n");
            return(*type);
        default :
            printf("None\n");
            return '0';
    }
    
}

// Machine (tab[18] + tab[19])
char get_machine(char * tab)
{
    printf(" Machine :                           ");
    //int machine; // = (tab[18] * 10) + tab[19];
    //char str[17] = {'\0'};
    uint16_t * machine = (uint16_t *) &tab[18];
    *machine = reverse_2(* machine);

    switch(*machine){
        case 2 :
            printf("SPARC\n");
            return(*machine);
        case 3 :
            printf("Intel 80386\n");
            return(*machine);
        case 4 :
            printf("Motorola 68000\n");
            return(*machine);
        case 7 :
            printf("Intel i860\n");
            return(*machine);
        case 8 :
            printf("MIPS I\n");
            return(*machine);
        case 19 :
            printf("Intell i960\n");
            return(*machine);        
        case 20 :
            printf("PowerPC\n");
            return(*machine);
        case 40 :
            printf("ARM\n");
            return(*machine);
        case 50 :
            printf("Intel IA64\n");
            return(*machine);
        case 62 :
            printf("x64\n");
            return(*machine);
        case 243 :
            printf("RISC-V\n");
            return(*machine);
        default:
            printf("Invalid");
            return '0';  
    
    }
}

//Version machine (tab[20] - tab[23])
uint32_t get_version_machine(char tab[65])
{
    uint32_t * version = (uint32_t *) &tab[20];
    *version = reverse_4(* version);
    printf(" Version :                           0x%X\n", *version);
    return *version;
}

//Entry (tab[24]-tab[27] si 32bits (class = 1), tab[24]-tab[31] si 64bits (class = 2))
uint32_t get_entry(char tab[65]) {
    
    uint32_t * entry_point = (uint32_t *) &tab[24];
    *entry_point = reverse_4(* entry_point);
    printf(" Entry point address :               0x%X\n", *entry_point);
    return *entry_point;
} 

//Start of headers (tab[28] - tab[31] si 32bits, tab[32] - tab[39] si 64bits)
uint32_t get_start_header(char tab[65])
{
    uint32_t * start_header = (uint32_t *) &tab[28];
    *start_header = reverse_4(* start_header);
    printf(" Start of program headers :          %d (bytes into file) \n", *start_header);
    return *start_header;
}

//Start of section header (tab[32] - tab[35] si 32bits, tab[40] - tab[47] si 64bits)
uint32_t get_start_section(char tab[65])
{
    uint32_t * start_section = (uint32_t *) &tab[32];
    *start_section= reverse_4(* start_section);
    
    printf(" Start of section headers :          %d (bytes into file) \n", *start_section );
    return *start_section;

}

//Flags (tab[36] si 32bits, tab[48] si 64bits, 4bytes)
uint32_t get_flags(char tab[65])
{
    uint32_t * flags = (uint32_t *) &tab[36];
    *flags = reverse_4(* flags);
    printf(" Flags :                             0x%x, Version5 EABI\n",*flags);
    return *flags;
}


//Size of header: tab[40] si 32bits,  tab[52] si 64bits, 2bytes
uint16_t get_size_of_header(char tab[65])
{
    uint16_t * size_of_header = (uint16_t *) &tab[40];
    *size_of_header = reverse_2(* size_of_header);
    printf(" Size of header :                    %d (bytes)\n",*size_of_header);
    return *size_of_header;
}

//Size of program headers: tab[42] si 32bits, tab[54] si 64bits, 2bytes
uint16_t get_size_of_program(char tab[65])
{
    uint16_t * size_of_program = (uint16_t *) &tab[42];
    *size_of_program = reverse_2(* size_of_program);
    printf(" Size of program headers :           %d (bytes)\n",*size_of_program);
    return *size_of_program;
}

//Number of program headers: tab[44] si 32bits, tab[56] si 64bits, 2bytes
uint16_t get_num_of_program_headers(char tab[65])
{
    uint16_t * num_program = (uint16_t *) &tab[44];
    *num_program = reverse_2(* num_program);
    printf(" Number of program headers :         %d\n",*num_program);
    return *num_program;
}

//Size of section headers: tab[46] si 32bits, tab[58] si 64bits, 2bytes
uint16_t get_size_of_section(char tab[65])
{
    uint16_t * size_section = (uint16_t *) &tab[46];
    *size_section = reverse_2(* size_section);
    printf(" Size of section headers :           %d (bytes)\n", *size_section);
    return *size_section;
}

//Number of section headers: tab[48] si 32bits, tab[60] si 64bits, 2bytes
uint16_t get_num_section_headers(char tab[65])
{
    uint16_t * num_section = (uint16_t *) &tab[48];
    *num_section = reverse_2(* num_section);
    printf(" Number of program headers :         %d\n",*num_section);
    return *num_section;
}

//Section header string table index: tab[50] si 32bits, tab[62] si 64bits, 2bytes
uint16_t get_section_table(char tab[65])
{
    uint16_t * string_table = (uint16_t *) &tab[50];
    *string_table = reverse_2(* string_table);
    printf(" Section header string table index : %d\n",* string_table);
    return *string_table;
}

// Etape 2

void get_sh_header(char * tab, header_info header,section_info ** sections)
{
    int i = 0, j = header.start_section;
    for (i; i < header.num_section; i++)
    {
        sections[i] = (section_info *) malloc (sizeof(section_info));
        if (sections[i] == NULL)
        {
            printf("Erreur d'allocation de memoire;");
            return NULL;
        }
    }
    i = 0 ;
    for (i; i < header.num_section; i++)
    {

        sections[i] -> sh_name = 1000*tab[j] + 100*tab[j+1] + 10*tab[j+2] + tab[j+3];

        sections[i] -> sh_type = 1000*tab[j+4] + 100*tab[j+5] + 10*tab[j+6] + tab[j+7];

	    sections[i] -> sh_flags = 1000*tab[j+8] + 100*tab[j+9] + 10*tab[j+10] + tab[j+11];

	    sections[i] -> sh_addr = 1000*tab[j+12] + 100*tab[j+13] + 10*tab[j+14] + tab[j+15];
        
	    sections[i] -> sh_offset = 1000*tab[j+16] + 100*tab[j+17] + 10*tab[j+18] + tab[j+19];
        
	    sections[i] -> sh_size = 1000*tab[j+20] + 100*tab[j+21] + 10*tab[j+22] + tab[j+23];
        
	    sections[i] -> sh_link = 1000*tab[j+24] + 100*tab[j+25] + 10*tab[j+26] + tab[j+27];
        
	    sections[i] -> sh_info = 1000*tab[j+28] + 100*tab[j+29] + 10*tab[j+30] + tab[j+31];
        
	    sections[i] -> sh_addralign = 1000*tab[j+32] + 100*tab[j+33] + 10*tab[j+34] + tab[j+35];
        
	    sections[i] -> sh_entsize = 1000*tab[j+36] + 100*tab[j+37] + 10*tab[j+38] + tab[j+39];
        
        j += header.size_section;
    }
}


void get_name(char * tab,header_info header, section_info** section_table)
{
    uint32_t * addr = (uint32_t *) &tab[header.start_section + header.string_table*header.size_section+16];
    *addr = reverse_4(*addr);

    for (int i = 0; i < header.num_section; i++)
    {
    section_table[i]->name = malloc (sizeof(char)*100);
    char * name = malloc (sizeof(char)*100);
    int adr_cal = *addr ;
    int sh_name = section_table[i]->sh_name;
    adr_cal += sh_name;
    strcat(name,&tab[adr_cal]);
    strcpy(section_table[i]->name,name);
    }
}
void affiche_section_table(section_info ** section_table,header_info header)
{
    //printf("              name        sh_name    sh_type   sh_flags     sh_addr   sh_offset   sh_size    sh_link  sh_info  sh_addralign  sh_entsize\n");
        for (int i = 0;i<header.num_section;i++)
    {
        printf("[%d] : ",i);
        printf("name:%s      n:%d   t:%d   f:%d   a:%d   o:%d    s:%d   l:%d   i:%d   ad:%d   e:%d  \n",section_table[i]->name,section_table[i]->sh_name,section_table[i]->sh_type,section_table[i]->sh_flags,section_table[i]->sh_addr,section_table[i]->sh_offset,section_table[i]->sh_size,section_table[i]->sh_link,section_table[i]->sh_info,section_table[i]->sh_addralign,section_table[i]->sh_entsize);
    }

}
/*
int  get_section_type(section_info ** section,int i){
    printf("section type : %02x\n", section->sh_type);
    switch(section[i]->sh_type)
    {
		case 1 :
			printf("PROGBITS\n");
			return 1;
		case 2 :
			printf(" SYMTAB\n");
			return 2;
		case 3 : 
			printf(" STRTAB\n");
			return 3;
		case 4 : 
			printf("RELA\n");
			return 4;
		case 5 : 
			printf("HASH\n");
			return 5;
		case 6 : 
			printf("DYNAMIC\n");
			return 6;
		case 7  :
			printf("NOTE\n");
			return 7;
		case 8 :
			printf("NOBITS\n");
			return 8;
		case 9 : 
			printf("REL\n");
			return 9;
		case 10 :
			printf("SHLIB\n");
			return 10;
		case 11 :
			printf("DYNSYM\n");
			return 11;
        case 0x70000000 :
            printf("LOPROC\n");
            return 0x70000000;
        case 0x7fffffff :
            printf("HIPROC\n");
            return 0x7fffffff;
        case 0x80000000 :
            printf("LOUSER\n");
            return 0x80000000;
        case 0xffffffff :
            printf("HIUSER\n");
            return 0xffffffff;
		case 0:
			printf("NULL\n");
			return 0;
        default:
            printf("ERREUR\n");
            return -1;
	}
}
*/
/*
int get_section_flags(section_info section){
	switch(section.sh_flags){
		case 1 : 
			printf("WRITE\n");
			return 1;
		case 2 :
			printf("ALLOC\n");
			return 2;
		case 3 :
			printf("EXECINSTR\n");
			return 3;
		default :
			printf("MASKPROC\n");
			return 0;
	}
}

int get_section_addr(section_info section){
    printf(" addresse : %0x\n", section.sh_addr);
    return section.sh_addr;
}

int get_offset_section(section_info section){
    printf(" offset : %d\n", section.sh_offset);
    return section.sh_offset;
}

int get_size_section(section_info section){
    printf(" size section : %d\n", section.sh_size);
    return section.sh_size;
}

/*
int get_link_section(header_info header){
    switch(section.sh_type){
        case 6: //DYNAMIC
            printf("%d\n", header.string_table);
            return hearder.string_table;
        case 5: //HASH
            printf("\n");
            return;
        case 9: //REL
            printf("\n");
            return ;
        case 4: //RELA
            printf("\n");
        case 2: //SYMTAB
            printf("\n");
        case 11: //DYNSYM
            printf("\n");
        default:
            printf("UNDEF\n");
            return 0;
    }
}

int get_info_section(){
    switch(sh_type){
        case 6 : //DYNAMIC
            printf("0\n");
            return 0;
        case 5 : //HASH
            printf("0\n");
            return 0;
        case 9 ://REL
            printf("");
            return
        case 4 : //RELA
            printf("");
            return
        case 2 : //SYMTAB
            printf("")
            return;
        case 11 : //DYNSYM
            printf("")
            return;
        default :
            printf("0\n");
            return 0;
    }
}

int get_addralign_section(){
    return sh_addralign;
}

int get_entsize_section{
    return sh_entsize;
}
*/
// Etape 3

/*
uint32_t get_index(char * name)
{
    
}
void etape3()
{
    scanf("choisir index ou name",choix);
    while choix != 1 || choix != 2 
    if index
    int index = scanf("choisir index")
    else
    char * name = scanf("choisir name")

    char choix[5];
    printf("Saisir 1 pour recherche par indice ou 2 pour recherche par nom\n");
    scanf("%s",&choix);
    while (choix != "1" || choix != "2")
    {
        printf("Choix invalide réessayer");
        scanf("%s",&choix);
    }
    if (choix == "1")
    {
        int index;
        printf("Choisir indice : ")
        scanf("%d",&index);
    }
    else
    {
        char * name;
        printf("Choisir le nom : ");
        scanf("%s",&name);
        int index = get_index(name);
    }


// }*/