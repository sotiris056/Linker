//Copyright (c) 2022 Soteris Kettenis (sotiris056), Lucas Berenguier (Berenguier), Ludovic Loubeau (LoubeauL), Camile Bertramond (CamilleBtd), Oceanne Ravier (OceanneRvr)

#ifndef _etape_1_H_
#define _etape_1_H_
#include <stdio.h>

typedef struct
{
    char * magic_number, class, data, version, abi_version, type, machine;
    uint32_t version_machine , entry , start_program , start_header, start_section , flags;
    uint16_t size_of_header, size_of_program, num_program, size_section, num_section, string_table;
    int os_abi;

} header_info;

typedef struct
{
    uint32_t * sh_name, * sh_type, * sh_flags, * sh_addr, * sh_offset, * sh_size, * sh_link, * sh_info, * sh_addralign, * sh_entsize;
    char * name;
} section_info;

void get_header(FILE * in, char tab[65],int len);
char * get_magic_number(char tab[65]);
char get_class(char tab[65]);
char get_data(char tab[65]);
char get_version(char tab[65]);
int get_os_abi(char tab[65]);
char get_abi_version(char  tab[65]);
char get_type(char tab[65]);
char get_machine(char tab[65]);
uint32_t get_version_machine(char tab[65]);
uint32_t get_entry(char tab[65]);
uint32_t get_start_header(char tab[65]);
uint32_t get_start_section(char tab[65]);
uint32_t get_flags(char tab[65]);
uint16_t get_size_of_header(char tab[65]);
uint16_t get_size_of_program(char tab[65]);
uint16_t get_num_of_program_headers(char tab[65]);
uint16_t get_size_of_section(char tab[65]);
uint16_t get_num_section_headers(char tab[65]);
uint16_t get_section_table(char tab[65]);
void get_sh_header(char * tab, header_info header,section_info ** sections);
int get_section_type(section_info section,int i);
int get_section_flags(section_info section);
int get_section_addr(section_info section);
int get_link_section(header_info header);
int get_offset_section(section_info section);
int get_size_section(section_info section);
void get_name(char * tab , header_info header, section_info** section_table);
void affiche_section_table(section_info ** section_table, header_info header);
#endif