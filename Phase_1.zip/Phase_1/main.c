//Copyright (c) 2022s Soteris Kettenis (sotiris056), Lucas Berenguier (Berenguier), Ludovic Loubeau (LoubeauL), Camile Bertramond (CamilleBtd), Oceanne Ravier (OceanneRvr)

#include <stdio.h>
#include <elf.h>
#include <stdlib.h>
#include <string.h>
#include "phase_1.h"
#include "util.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>


int main (int argc , char * argv[])
{
    struct stat sb;
    
    
    FILE * f = fopen(argv[1], "r");
    if (f == NULL)
    {
        printf ("Erreur d'ouverture du fichier %s", argv[1]);
        return -1;
    }
    
    if (stat(argv[1], &sb) == -1) {
        perror("stat");
        exit(EXIT_FAILURE);
    }
    
    char * file;//[sb.st_size+1];
    int len = sb.st_size + 1;
    file = (char *) malloc (len * sizeof(char));
    header_info header;
    section_info section;

    //Etape 1: Affichage de l'en-tête
    
    printf("ELF Header:\n");
    
    get_header(f,file,len);
    header.magic_number = get_magic_number(file);
    header.class = get_class(file);
    header.data = get_data(file);
    header.version = get_version(file);
    header.os_abi = get_os_abi(file);
    header.abi_version = get_abi_version(file);
    header.type = get_type(file);
    header.machine = get_machine(file);
    header.version_machine = get_version_machine(file);
    header.entry = get_entry(file);
    header.start_header = get_start_header(file);
    header.start_section = get_start_section(file);
    header.flags = get_flags(file);
    header.size_of_header = get_size_of_header(file);
    header.size_of_program = get_size_of_program(file);
    header.num_program = get_num_of_program_headers(file);
    header.size_section = get_size_of_section(file);
    header.num_section = get_num_section_headers(file);
    header.string_table = get_section_table(file);
    section_info ** section_table = (section_info **) malloc (header.num_section * sizeof(section_info *));
    get_sh_header(file,header,section_table);
    get_name(file,header,section_table);
    /*for(int i=0; i<header.num_section; i++){
        get_section_type(section_table,i);
    }*/
    affiche_section_table(section_table,header);

    
    fclose(f);
    return 0;
}