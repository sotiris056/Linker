#ifndef _ARITHMETIC_FUNCTIONS_H_
#define _ARITHMETIC_FUNCTIONS_H_

int hex_to_dec (char * num);
char * dec_to_hex (int a);

#endif